# Img_prcs_package

Description. 

| The package Img_prcs_package is used to:                                                                                                                                                                                                       |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1. Processing<br />    - Histogram matching<br />    - Structural simalarity<br /><br />2. Resize Image Utils:<br />    - Read Image<br />    - Save Image<br />    - Plot Image<br />    - Plot result<br />    - Plot Histogram |

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install Img_prcs_package
```

## Usage

```python
from Img_prcs_package.processing import combination
combination.find_difference()
```

## Author

Dev_yuji

## License

[MIT](https://choosealicense.com/licenses/mit/)
